package com.cmas.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmasSystemExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}

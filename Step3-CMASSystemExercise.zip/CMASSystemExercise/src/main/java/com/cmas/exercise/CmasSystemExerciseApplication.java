package com.cmas.exercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmasSystemExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmasSystemExerciseApplication.class, args);
	}

}
